---
title: 指弹-butter-fly
tags:
  - 吉他
categories:
  - 吉他
abbrlink: 5f72
date: 2020-04-09 14:23:28
description:
---



六弦到一弦DADF#AD，标准调弦为EADGBE，简单来讲，就是 一二六弦降全音，三弦降半音。演示：


<iframe src="//player.bilibili.com/player.html?aid=4331458&bvid=BV1Bs411z7wc&cid=7007793&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>


<!--more-->


<iframe src="//player.bilibili.com/player.html?aid=29021970&bvid=BV1us411u7ei&cid=50343596&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>









