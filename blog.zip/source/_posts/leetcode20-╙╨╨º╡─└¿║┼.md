---
title: leetcode20-有效的括号
tags:
  - leetcode
categories:
  - 技术
abbrlink: 74a
date: 2020-04-15 11:33:09
description:
---










{% tabs Tab标签列表 %}
  <!-- tab 题目要求 -->
  给定一个只包括 '('，')'，'{'，'}'，'['，']' 的字符串，判断字符串是否有效。

有效字符串需满足：

左括号必须用相同类型的右括号闭合。

左括号必须以正确的顺序闭合。

注意空字符串可被认为是有效字符串。

  <!-- endtab -->
  <!-- tab 示例 -->

示例 1:

输入: "()"
输出: true
示例 2:

输入: "()[]{}"
输出: true
示例 3:

输入: "(]"
输出: false
示例 4:

输入: "([)]"
输出: false
示例 5:

输入: "{[]}"
输出: true

  <!-- endtab -->

{% endtabs %}



<!--more-->


# 思路

观察下面的示例，可以看出括号需要满足闭合以及括号匹配的问题。

那这里可以利用栈来实现，先把字符串遍历，取出字符，左括号入栈，遇到右括号先判断是否和栈顶的符合匹配，如果匹配，则弹出；再进行下一步右括号的匹配。



```java

import java.util.Stack;

class Solution {
    public boolean isValid(String s) {


        Stack<Character> stack = new Stack<>();
        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            if(c=='(' || c=='['||c=='{'){
                stack.push(c);
            }else{
                if(stack.isEmpty()){//说明最左边为右括号。
                    return false;
                }
                char topChar=stack.pop();
                if(topChar!='(' && c==')'){
                    return false;
                }
                if(topChar!='[' && c==']'){
                    return false;
                }
                if(topChar!='{' && c=='}'){
                    return false;
                }
            }
        }
//        return true;错误，举例"["
        return stack.isEmpty();
    }
}
```



![结果](https://img.senup.cn/blog/20200415/nkl9w4jfru3G.png?imageslim)



