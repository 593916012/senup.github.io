---
title: 博客进阶写作技巧
tags:
  - 技术
categories:
  - 技术
abbrlink: 86f9
date: 2019-03-01 10:41:44
description:
---


本文介绍了Hexo 中常用的内置标签，包括 文本居中引用，note 标签、label 标签、button 标签、tab 标签以及代码块的高级用法，通过使用写作标签可以快速编写样式丰富的文档片段。

<!--more-->

# 文本居中引用

效果：

{% cq %}
你是巨大的海洋
我是雨落在你身上
我看到远方
爱情的模样
{% endcq %}

源码：

```
{% cq %}
你是巨大的海洋
我是雨落在你身上
我看到远方
爱情的模样
{% endcq %}
```

# tab 标签

首先还是需要在Next主题配置文件中配置：

```yaml
文件位置：~/blog/themes/next/_config.yml# Tabs tag.
tabs:
  enable: true
  transition:
    tabs: true
    labels: true
  border_radius: 0
```


使用示例如下：

```xml
{% tabs Tab标签列表 %}
  <!-- tab 标签页1 -->
    标签页1文本内容
  <!-- endtab -->
  <!-- tab 标签页2 -->
    标签页2文本内容
  <!-- endtab -->
  <!-- tab 标签页3 -->
    标签页3文本内容
  <!-- endtab -->
{% endtabs %}
```

{% tabs Tab标签列表 %}
  <!-- tab 标签页1 -->
    标签页1文本内容
  <!-- endtab -->
  <!-- tab 标签页2 -->
    标签页2文本内容
  <!-- endtab -->
  <!-- tab 标签页3 -->
    标签页3文本内容
  <!-- endtab -->
{% endtabs %}




tab 标签用于快速创建 tab 选项卡，语法如下

```
{% tabs [Unique name], [index] %}
  <!-- tab [Tab caption]@[icon] -->
  标签页内容（支持行内标签）
  <!-- endtab -->
{% endtabs %}
```

其中，各参数意义如下：

> - Unique name: 全局唯一的 Tab 名称，将作为各个标签页的 id 属性前缀
> - index: 当前激活的标签页索引，如果未定义则默认选中显示第一个标签页，如果设为 - 1 则默认隐藏所有标签页
> - Tab caption: 当前标签页的标题，如果不指定则会以 Unique name 加上索引作为标题
> - icon: 在标签页标题中添加 Font awesome 图标
>

需要注意的是：标签内嵌套代码的话，首尾要去掉三个`，也就是不能指定编程语言

# label 标签

首先需要在Next主题`_config.xml`中配置：

```yaml
# Label tag.
label: true
```

通过 label 标签可以为文字添加背景色，语法如下：

```verilog
{% label [class]@text  %}
```

支持的 class 种类包括 `default` `primary` `success` `info` `warning` `danger`，默认使用 `default` 作为缺省。

使用示例如下：

```verilog
{% label default@默认 %}
{% label info@信息 %}
{% label warning@警告 %}
{% label success@成功 %} 
{% label primary@原始 %}
{% label danger@危险 %}
```

{% label default@默认 %}
{% label info@信息 %}
{% label warning@警告 %}
{% label success@成功 %} 
{% label primary@原始 %}
{% label danger@危险 %}

可在主题配置文件中设置 `label: false` 来取消 label 标签默认 CSS 样式。





# note标签

在 Next 主题的配置文件`_config.yml` 中找到下面的部分，目前有 3 种 style 可选，这里我选用的 `flat`，其他两种大家可以自行试一下效果，另外图标的显示与否也可在此配置。

```yaml
/themes/next/_config.yml
# Note tag (bs-callout)
note:
# Note tag style values:
# - simple    bs-callout old alert style. Default.
# - modern    bs-callout new (v2-v3) alert style.
# - flat      flat callout style with background, like on Mozilla or StackOverflow.
# - disabled  disable all CSS styles import of note tag.
  style: flat
  icons: true
  border_radius: 3
```



## 第一种方式

```
<div class="note default"><p>default</p></div>
```

<div class="note default"><p>default</p></div>



```
<div class="note primary"><p>primary</p></div>
```



<div class="note primary"><p>primary</p></div>

```
<div class="note success"><p>success</p></div>
```

<div class="note success"><p>success</p></div>



```
<div class="note info"><p>info</p></div>
```

<div class="note info"><p>info</p></div>



```
<div class="note warning"><p>warning</p></div>
```

<div class="note warning"><p>warning</p></div>



```
<div class="note danger"><p>danger</p></div>
```

<div class="note danger"><p>danger</p></div>



```
<div class="note danger no-icon"><p>danger no-icon</p></div>
```

<div class="note danger no-icon"><p>danger no-icon</p></div>



## 第二种方式



1、没有定义样式类别

{% note %}
(没有定义样式类别)
{% endnote %}

```
{% note %}
(没有定义样式类别)
{% endnote %}
```



2、默认的类别

{% note default %}
默认形式的类别
{% endnote %}

```
{% note default %}
默认形式的类别
{% endnote %}
```



3、primary形式的类别

{% note primary %}
首要类型形式
{% endnote %}

```
{% note primary %}
首要类型形式
{% endnote %}
```



4、info形式的类别

{% note info %}
info形式的类别
{% endnote %}

```
{% note info %}
info形式的类别
{% endnote %}
```



5、success形式的类别

{% note success %}
success形式的类别
{% endnote %}

```
{% note success %}
success形式的类别
{% endnote %}
```



6、warning形式的类别

{% note warning %}
warning形式的类别
{% endnote %}

```
{% note warning %}
warning形式的类别
{% endnote %}
```



7、danger形式的类别

{% note danger %}
danger形式的类别
{% endnote %}

```
{% note danger %}
danger形式的类别
{% endnote %}
```





# button标签

效果：

{% btn https://www.baidu.com, 点击下载百度, download fa-lg fa-fw %}



```
{% btn https://www.baidu.com, 点击下载百度, download fa-lg fa-fw %}
```

关于按钮的更多使用可以前往[这个页面](https://almostover.ru/2016-01/hexo-theme-next-test/#Button-tag-test)查看。





# 代码块进阶用法

可以通过为代码块附加参数的形式为其添加更丰富的信息提示，效果如下：



```java Hellow World https://www.senup.cn/p/86f9.html 链接
    private int[] data;
    private int size;
```




代码块进阶语法规则：

参数可选：[language] [title] [url] [link text]
如`java Hellow World https://www.senup.cn/ 链接`

其中，各参数意义如下：

> - langugae：语言名称，引导渲染引擎正确解析并高亮显示关键字
> - title：代码块标题，将会显示在左上角
> - url：链接地址，如果没有指定 link text 则会在右上角显示 link
> - link text：链接名称，指定 url 后有效，将会显示在右上角
>

*url 必须为有效链接地址才会以链接的形式显示在右上角，否则将作为标题显示在左上角。以 url 为分界，左侧除了第一个单词会被解析为 language，其他所有单词都会被解析为 title，而右侧的所有单词都会被解析为 link text。*

如果不想填写 title，可以在 language 和 url 之间添加至少三个空格。

代码块支持多种语言高亮预设，详细的语言列表可查看 [Ivan.nginx | Hexo 代码块中的颜色方案](https://almostover.ru/2016-07/hexo-highlight-code-styles/)。

可以在站点配置文件中设置 `highlight.auto_detect: true` 来开启自动语言检测高亮。

```diff
_config.yml highlight:
   enable: true
   line_number: false
-  auto_detect: false
+  auto_detect: true
   tab_replace:
```

如果设置语言为 diff，可以在代码前添加 `+` 和 `-` 来使用如上所示的高亮增删行提示效果，在展示代码改动痕迹时比较实用。

更多代码块高亮的个性化设置请参见 [猪猪侠 | Hexo 下的语法高亮拓展修改](https://www.ofind.cn/blog/HEXO/HEXO下的语法高亮拓展修改.html#设置代码添加删除标记)

