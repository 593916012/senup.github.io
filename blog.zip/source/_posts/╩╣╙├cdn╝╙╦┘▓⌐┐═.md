---
title: 使用cdn加速博客
tags:
  - 技术
categories:
  - 技术
abbrlink: 2acf
date: 2019-08-17 16:07:26
description:
---



折腾了半天，重新配置了博客，并加入了又拍云CDN优化，现在这访问速度，自己都忍不住想多刷新几次。

![加入cdn前后速度对比](https://img.senup.cn/blog/20200417/CGLfPnFlAVYi.png?imageslim)









